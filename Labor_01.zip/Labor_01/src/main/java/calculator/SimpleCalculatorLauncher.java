package calculator;

import javafx.application.Application;

public class SimpleCalculatorLauncher {
    public static void main(String[] args) {
        Application.launch(SimpleCalculator.class,args);
    }
}
